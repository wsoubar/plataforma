// app-services.js

(function(){

    var app = angular.module('plataformaApp-services', []);

})();